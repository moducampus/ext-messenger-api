-----------------------------------------------------------------------------------------------------------------------------------
다국어를 지원하지 않는 DB에서 다국어를 사용할 경우 이력 테이블 생성 시 SND_MSG NVARCHAR(2000), MSG_TITLE NVARCHAR(200)으로 생성한다. 
예) EUC-KR을 사용 중인 DB에서 다국어인 중국어 간체를 전송할 경우
-----------------------------------------------------------------------------------------------------------------------------------

# 신규 사용자용 테이블 생성(추가 필드 사용:ETC_COLUMN_USE=TRUE)
CREATE TABLE TBL_SUBMIT_QUEUE (
  	CMP_MSG_ID          VARCHAR(20)    NOT NULL,
	CMP_MSG_GROUP_ID    VARCHAR(20),    
	USR_ID             VARCHAR(16)    NOT NULL,
	SMS_GB              CHAR(1)        DEFAULT '1',
	USED_CD             CHAR(2)        NOT NULL,
	RESERVED_FG         CHAR(1)        NOT NULL,
	RESERVED_DTTM       CHAR(14)	   NOT NULL,
	SAVED_FG            CHAR(1)        DEFAULT '0',
	RCV_PHN_ID          VARCHAR(24)    NOT NULL,
	SND_PHN_ID          VARCHAR(24),
	NAT_CD              VARCHAR(8),
	ASSIGN_CD           VARCHAR(5)     DEFAULT '00000',
	SND_MSG             VARCHAR(2000),
	CALLBACK_URL        VARCHAR(120),
	CONTENT_CNT         INTEGER         DEFAULT 0,  
	CONTENT_MIME_TYPE   VARCHAR(128),   
	CONTENT_PATH        VARCHAR(1024), 
	CMP_SND_DTTM        CHAR(14),
	CMP_RCV_DTTM        CHAR(14),
	REG_SND_DTTM        CHAR(14),
	REG_RCV_DTTM        CHAR(14),
	MACHINE_ID          CHAR(2),
	SMS_STATUS          CHAR(1)        DEFAULT '0',
	RSLT_VAL            CHAR(5),
	MSG_TITLE	    VARCHAR(200),
	TELCO_ID	    CHAR(4),
	ASP_ID		    VARCHAR(32),
	DCS        	    INTEGER         DEFAULT 0,  
	ETC_CHAR_1	    VARCHAR(100),
	ETC_CHAR_2	    VARCHAR(100),
	ETC_CHAR_3	    VARCHAR(100),
	ETC_CHAR_4	    VARCHAR(100),
	ETC_INT_5	    INTEGER,
	ETC_INT_6	    INTEGER,
  PRIMARY KEY(CMP_MSG_ID)
);

# 신규 사용자용 테이블 생성(추가 필드 미사용:ETC_COLUMN_USE=FALSE)
CREATE TABLE TBL_SUBMIT_QUEUE (
  	CMP_MSG_ID          VARCHAR(20)    NOT NULL,
	CMP_MSG_GROUP_ID    VARCHAR(20),    
	USR_ID             VARCHAR(16)    NOT NULL,
	SMS_GB              CHAR(1)        DEFAULT '1',
	USED_CD             CHAR(2)        NOT NULL,
	RESERVED_FG         CHAR(1)        NOT NULL,
	RESERVED_DTTM       CHAR(14)	   NOT NULL,
	SAVED_FG            CHAR(1)        DEFAULT '0',
	RCV_PHN_ID          VARCHAR(24)    NOT NULL,
	SND_PHN_ID          VARCHAR(24),
	NAT_CD              VARCHAR(8),
	ASSIGN_CD           VARCHAR(5)     DEFAULT '00000',
	SND_MSG             VARCHAR(2000),
	CALLBACK_URL        VARCHAR(120),
	CONTENT_CNT         INTEGER         DEFAULT 0,  
	CONTENT_MIME_TYPE   VARCHAR(128),   
	CONTENT_PATH        VARCHAR(1024), 
	CMP_SND_DTTM        CHAR(14),
	CMP_RCV_DTTM        CHAR(14),
	REG_SND_DTTM        CHAR(14),
	REG_RCV_DTTM        CHAR(14),
	MACHINE_ID          CHAR(2),
	SMS_STATUS          CHAR(1)        DEFAULT '0',
	RSLT_VAL            CHAR(5),
	MSG_TITLE	    VARCHAR(200),
	TELCO_ID	    CHAR(4),
	ASP_ID		    VARCHAR(32),
	DCS        	    INTEGER         DEFAULT 0,  
  PRIMARY KEY(CMP_MSG_ID)
);

# 인덱스 생성_1
CREATE INDEX IDX_SUBMIT_QUEUE_1 ON TBL_SUBMIT_QUEUE (SMS_STATUS, RESERVED_FG);

# 인덱스 생성_2
# 주의 : IDX_SUBMIT_QUEUE_2 인덱스를 생성하지 않을 시 데드락 발생.
CREATE INDEX IDX_SUBMIT_QUEUE_2 ON TBL_SUBMIT_QUEUE (CMP_MSG_ID, SMS_STATUS);
