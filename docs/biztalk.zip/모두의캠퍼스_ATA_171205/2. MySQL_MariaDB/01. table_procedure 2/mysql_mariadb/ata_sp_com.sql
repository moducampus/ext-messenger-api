DELIMITER //

/**
 * ATA가 공통으로 사용하는 MySQL Stored Procedure 이다.
 * 고객사의 표준 프로시저를 이용하여 테이블 변경을 원할 경우
 * 아래의 프로시저를 수정하여 반영할 수 있으나,
 * INPUT PARAMETER 및 RESULTSET 결과는 아래 정의된
 * 대로 꼭 제공해 주어야 한다.
 */


/**************************************************************************/
/* NAME : sp_common_create
/* DESC : 각 서비스에서 공통적으로 사용하는 테이블을 사용한다.
/* PARAMETERS
/*   N/A
/* REMARK    
/*   N/A
/**************************************************************************/
DROP PROCEDURE IF EXISTS sp_common_create //
CREATE PROCEDURE sp_common_create
(
)
BEGIN

    /* create ata_banlist table */
    SET @s = CONCAT( "
        CREATE TABLE IF NOT EXISTS ata_banlist
        ( service_type  char(2)     NOT NULL
        , ban_seq       int(11)     NOT NULL
        , ban_type      char(1)     NOT NULL
        , content       varchar(45) NOT NULL
        , send_yn       char(1)     NOT NULL default 'N'
        , ban_status_yn char(1)     NOT NULL default 'Y'
        , reg_date      datetime    NOT NULL default '1970-01-01 00:00:00'
        , reg_user      varchar(20)
        , update_date   datetime    NOT NULL default '1970-01-01 00:00:00'
        , update_user   varchar(20)
        , PRIMARY KEY (service_type, ban_seq)
        , KEY ix_ata_banlist_01 (ban_type, service_type, ban_status_yn)
        , KEY ix_ata_banlist_02 (content)
        ) ENGINE=InnoDB ;");
    PREPARE stmt FROM @s;
    EXECUTE stmt;

END
//


/**************************************************************************/
/* NAME : sp_common_banlist
/* DESC : 전송차단테이블에서 전송차단 리스트 조회한다.
/* PARAMETERS
/*   OUT p_list : Resultset
/*   IN  p_service_type : 서비스 구분
/* REMARK    
/*   N/A
/**************************************************************************/
DROP PROCEDURE IF EXISTS sp_common_banlist //
CREATE PROCEDURE sp_common_banlist
(
   IN  p_service_type  VARCHAR(2)
)
BEGIN

    SELECT service_type
         , ban_type
         , content
         , send_yn
    FROM   ata_banlist
    WHERE  service_type = p_service_type
    AND    ban_type  <> 'R'
    AND    ban_status_yn = 'Y';

END
//


/**************************************************************************/
/* NAME : sp_common_checkprivilege
/* DESC : 테이블 관리 권한을 체크한다.
/* PARAMETERS
/*   N/A
/* REMARK    
/*   N/A
/**************************************************************************/
DROP PROCEDURE IF EXISTS sp_common_checkprivilege //
CREATE PROCEDURE sp_common_checkprivilege
(
)
BEGIN

    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION ROLLBACK;

    START TRANSACTION;
    
    CREATE TABLE IF NOT EXISTS ata_temp (a char(1));

    DROP TABLE IF EXISTS ata_temp;

    COMMIT;

END
//

DELIMITER ;
