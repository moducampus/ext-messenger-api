DELIMITER //

/**
 * 메시지 서비스를 위한 MySQL Stored Procedure 이다.
 * 고객사의 표준 프로시저를 이용하여 테이블 변경을 원할 경우
 * 아래의 프로시저를 수정하여 반영할 수 있으나,
 * INPUT PARAMETER 및 RESULTSET 결과는 아래 정의된 대로
 * 꼭 제공해 주어야 한다.
 */


/**************************************************************************/
/* NAME : sp_mmt_create
/* DESC : 메시지 서비스 관련 테이블을 생성한다.
/* PARAMETERS
/*   N/A
/* REMARK
/*   ata_mmt_tran :  메시지 전송 테이블
/*   ata_mmt_client : 동보 전송을 위한 수신번호 테이블(ata_mmt_tran의 Detail)
/**************************************************************************/
DROP PROCEDURE IF EXISTS sp_mmt_create //
CREATE PROCEDURE sp_mmt_create
(
)
BEGIN

    /* create ata_mmt_tran table, master */
    SET @sql = CONCAT("
        CREATE TABLE IF NOT EXISTS ata_mmt_tran
        ( mt_pr                 int(11)       NOT NULL auto_increment
        , mt_refkey             varchar(20)
        , priority              char(2)       NOT NULL default 'S'
        , date_client_req       datetime      NOT NULL default '1970-01-01 00:00:00'
        , subject               varchar(40)   NOT NULL default ' '
        , content               varchar(4000) NOT NULL
        , callback              varchar(25)   NOT NULL
        , msg_status            char(1)       NOT NULL default '1'
        , recipient_num         varchar(25)
        , date_mt_sent          datetime
        , date_rslt             datetime
        , date_mt_report        datetime
        , report_code           char(4)
        , rs_id                 varchar(20)
        , country_code          varchar(8)    NOT NULL default '82'
        , msg_type              int(11)       NOT NULL default '1008'
        , crypto_yn             char(1)                default 'Y'
        , ata_id                char(2)                default ' '
        , reg_date              timestamp              default CURRENT_TIMESTAMP
        , sender_key            varchar(40)   NOT NULL
        , template_code         varchar(30)
        , response_method       varchar(20)   NOT NULL default 'push'
        , ad_flag               char(1) NOT NULL default 'N'
		, kko_btn_type          char(1) 
		, kko_btn_info          varchar(4000)
		, img_url               varchar(200)
        , img_link              varchar(100)
        , etc_text_1            varchar(100)
        , etc_text_2            varchar(100)
        , etc_text_3            varchar(100)
        , etc_num_1             int(11)
        , etc_num_2             int(11)
        , etc_num_3             int(11)
        , etc_date_1            datetime
        , PRIMARY KEY (mt_pr)
        , KEY ix_ata_mmt_tran_01 (msg_status, date_client_req)
        , KEY ix_ata_mmt_tran_02 (recipient_num)
        , KEY ix_ata_mmt_tran_03 (ata_id , date_client_req)
        , KEY ix_ata_mmt_tran_04 (sender_key, template_code)
        ) ENGINE=InnoDB ;");
    PREPARE stmt FROM @sql;
    EXECUTE stmt;

END
//

/**************************************************************************/
/* NAME : sp_mmt_log_create
/* DESC : 메시지 로그 테이블을 생성한다.
/* PARAMETERS
/*   p_log_table : 로그테이블 변경 postfix(년월)
/* REMARK
/*   p_log_table이 YYYYMM이 default이지만 값을 변경하면 YYYY등의 확장 가능
/**************************************************************************/
DROP PROCEDURE IF EXISTS sp_mmt_log_create //
CREATE PROCEDURE sp_mmt_log_create
(
     IN  p_log_table  VARCHAR(6)
)
BEGIN

    /* create ata_mmt_log_yyyymm table */
    IF p_log_table <> '' THEN
        SET @sql = CONCAT( "
            CREATE TABLE IF NOT EXISTS ata_mmt_log_", p_log_table ,"
            ( mt_pr                 int(11)       NOT NULL
            , mt_refkey             varchar(20)
            , priority              char(2)       NOT NULL default 'S'
            , date_client_req       datetime      NOT NULL default '1970-01-01 00:00:00'
            , subject               varchar(40)   NOT NULL default ' '
            , content               varchar(4000) NOT NULL
            , callback              varchar(25)   NOT NULL
            , msg_status            char(1)       NOT NULL default '1'
            , recipient_num         varchar(25)
            , date_mt_sent          datetime
            , date_rslt             datetime
            , date_mt_report        datetime
            , report_code           char(4)
            , rs_id                 varchar(20)
            , country_code          varchar(8)    NOT NULL default '82'
            , msg_type              int(11)       NOT NULL default '1008'
            , crypto_yn             char(1)                default 'Y'
            , ata_id                char(2)                default ' '
            , reg_date_tran         timestamp              default 0
            , reg_date              timestamp              default CURRENT_TIMESTAMP
            , sender_key            varchar(40)   NOT NULL
            , template_code         varchar(30)
            , response_method       varchar(20)   NOT NULL default 'push'
            , ad_flag               char(1) NOT NULL default 'N'
			, kko_btn_type          char(1) 
		    , kko_btn_info          varchar(4000)
			, img_url               varchar(200)
            , img_link              varchar(100)
            , etc_text_1            varchar(100)
            , etc_text_2            varchar(100)
            , etc_text_3            varchar(100)
            , etc_num_1             int(11)
            , etc_num_2             int(11)
            , etc_num_3             int(11)
            , etc_date_1            datetime
            , PRIMARY KEY (mt_pr)
            , KEY ix_ata_mmt_log_", p_log_table, "_01 (date_client_req, recipient_num)
            , KEY ix_ata_mmt_log_", p_log_table, "_02 (date_mt_report, report_code)
            , KEY ix_ata_mmt_log_", p_log_table, "_03 (msg_status)
            , KEY ix_ata_mmt_log_", p_log_table, "_04 (sender_key, template_code)
            ) ENGINE=InnoDB ;" );
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
    END IF;
END
//

/**************************************************************************/
/* NAME : sp_mmt_log_temp_create
/* DESC : 메시지 로그 이동을 위한 임시테이블을 생성한다.
/* PARAMETERS
/*   N/A
/* REMARK
/*   N/A
/**************************************************************************/
DROP PROCEDURE IF EXISTS sp_mmt_log_temp_create //
CREATE PROCEDURE sp_mmt_log_temp_create
(
)
BEGIN

    SET @sql = CONCAT( "
        CREATE TEMPORARY TABLE IF NOT EXISTS ata_mmt_log_temp
        ( mt_pr                 int(11)       NOT NULL
        , mt_refkey             varchar(20)
        , priority              char(2)       NOT NULL default 'S'
        , date_client_req       datetime      NOT NULL default '1970-01-01 00:00:00'
        , subject               varchar(40)   NOT NULL
        , content               varchar(4000) NOT NULL
        , callback              varchar(25)   NOT NULL
        , msg_status            char(1)       NOT NULL default '1'
        , recipient_num         varchar(25)
        , date_mt_sent          datetime
        , date_rslt             datetime
        , date_mt_report        datetime
        , report_code           char(4)
        , rs_id                 varchar(20)
        , country_code          varchar(8)    NOT NULL default '82'
        , msg_type              int(11)
        , crypto_yn             char(1)                default 'Y'
        , ata_id                char(2)                default ' '
        , reg_date_tran         TIMESTAMP              DEFAULT 0
        , reg_date              TIMESTAMP              DEFAULT CURRENT_TIMESTAMP
        , sender_key            varchar(40)        NOT NULL
        , template_code         varchar(30)
        , response_method       varchar(20)        NOT NULL default 'push'
        , ad_flag               char(1) NOT NULL default 'N'
		, kko_btn_type          char(1) 
		, kko_btn_info          varchar(4000)
		, img_url               varchar(200)
        , img_link              varchar(100)
        , etc_text_1            varchar(100)
        , etc_text_2            varchar(100)
        , etc_text_3            varchar(100)
        , etc_num_1             int(11)
        , etc_num_2             int(11)
        , etc_num_3             int(11)
        , etc_date_1            datetime
        )ENGINE=HEAP; " );
    PREPARE stmt FROM @sql;
    EXECUTE stmt;

END
//


/**************************************************************************/
/* NAME : sp_mmt_tran_select
/* DESC : 메시지 전송 테이블로 부터 전송할 메시지를 조회한다.
/* PARAMETERS
/*   OUT p_list : Resultset
/*   IN  p_priority    : 메시지 우선순위(VF/F/S)
/*   IN  p_ttl         : 전송 유효 시간 (단위: 분)
/*   IN  p_ata_id     : ATA 이중화시 사용되는 ATA ID (' ' 인 경우: 이중화 사용안함, ' ' 아닌 경우: 이중화 사용함)
/*   IN  p_bancheck_yn : 수신차단테이블 체크 여부
/* REMARK
/*   조회 결과의 필드명은 꼭 지켜져야 한다.
/*   한번에 쿼리할 수 있는 개수는 조절 가능하지만, 변경 후 테스트가 필요하다.
/**************************************************************************/
DROP PROCEDURE IF EXISTS sp_mmt_tran_select //
CREATE PROCEDURE sp_mmt_tran_select
(
     IN p_priority     CHAR(2)
   , IN p_ttl          INT
   , IN p_ata_id      CHAR(2)
   , IN p_bancheck_yn  CHAR(1)
)
BEGIN

    DECLARE CONTINUE HANDLER FOR SQLWARNING ROLLBACK;
    DECLARE CONTINUE HANDLER FOR NOT FOUND ROLLBACK;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION ROLLBACK;

    /** update ata_id */
    IF p_ata_id <> ' ' THEN

    SET @sql = CONCAT( "
        UPDATE ata_mmt_tran
        SET    ata_id = ?
        WHERE  priority = ?
        AND    concat(msg_status , '') = '1'
        AND    date_client_req < sysdate()
        AND    date_client_req > date_sub(sysdate(), interval ? minute)
        AND    ata_id = ' '
        LIMIT 300 ");

    SET @p_ata_id = p_ata_id;
    SET @p_priority = p_priority;
    SET @p_ttl = p_ttl;

    START TRANSACTION;
    PREPARE stmt FROM @sql;
    EXECUTE stmt USING @p_ata_id, @p_priority, @p_ttl;
    COMMIT;

    END IF;

    /** real select */
    SELECT A.mt_pr                 AS mt_pr
         , A.mt_refkey             AS mt_refkey
         , A.subject               AS subject
         , 0                       AS content_type
         , A.content               AS content
         , A.priority              AS priority
         , 'N'                     AS broadcast_yn
         , A.callback              AS callback
         , A.recipient_num         AS recipient_num
         , NULL                    AS recipient_net
         , NULL                    AS recipient_npsend
         , A.country_code          AS country_code
         , A.date_client_req       AS date_client_req
         , NULL                    AS charset
         , '1'                     AS msg_class
         , NULL                    AS attach_file_group_key
         , A.msg_type              AS msg_type
         , A.crypto_yn             AS crypto_yn
         , '3'                     AS service_type
         , NULL                    AS ttl
         , A.sender_key            AS sender_key
         , A.template_code         AS template_code
         , A.response_method       AS response_method
         , B.ban_type              AS ban_type
         , B.send_yn               AS send_yn
         , A.kko_btn_info          AS kko_btn_info
		 , A.kko_btn_type          AS kko_btn_type
		 , A.ad_flag               AS ad_flag
		 , A.img_url               AS img_url
         , A.img_link              AS img_link
    FROM   ata_mmt_tran A
    LEFT OUTER JOIN ata_banlist B
    ON    A.recipient_num = B.content
    AND   '3' = B.service_type
    AND   B.ban_type = 'R'
    AND   B.ban_status_yn = 'Y'
    WHERE A.ata_id = p_ata_id
    AND   A.priority = p_priority
    AND   A.msg_status = '1'
    AND   A.date_client_req < sysdate()
    AND   A.date_client_req > date_sub(sysdate(), interval p_ttl minute)
    LIMIT 300;

END
//

/**************************************************************************/
/* NAME : sp_mmt_update
/* DESC : 메시지 발송을 위한 큐에 데이터 적재 후 상태정보를 업데이트 한다.
/* PARAMETERS
/*   IN p_table_divi            : 업데이트할 테이블(마스터/디테일 ) 구분
/*   IN p_update_all            : 동보테이블 전체 업데이트 여부
/*   IN p_mt_pr                 : 마스터 테이블 키
/*   IN p_mt_seq                : 디테일 테이블 키(개별전송시 0, 동보전송시 해당순번
/*   IN p_msg_status            : 메시지 상태 (정상-2, 실패-3)
/*   IN p_mt_report_code_ib     : 오류시 결과 코드
/*   IN p_mt_report_code_ibtype : 오류결과코드분류
/* REMARK
/*   N/A
/**************************************************************************/
DROP PROCEDURE IF EXISTS sp_mmt_update //
CREATE PROCEDURE sp_mmt_update
(
     IN p_table_divi             CHAR(1)
   , IN p_update_all_yn          CHAR(1)
   , IN p_mt_pr                  INT
   , IN p_mt_seq                 INT
   , IN p_msg_status             CHAR(1)
   , IN p_mt_report_code_ib      CHAR(4)
   , IN p_mt_report_code_ibtype  CHAR(1)
)
BEGIN

    SET @sql = CONCAT( " UPDATE ata_mmt_tran SET " );

    SET @sql = CONCAT( @sql , "
        msg_status             = ?,
        report_code            = ?,
        date_mt_sent           = sysdate() " );

    IF ( p_msg_status = '3' ) THEN
        SET @sql = CONCAT( @sql , ", date_rslt  = sysdate() " );
    END IF;

    SET @sql = CONCAT( @sql , " WHERE mt_pr  = ? " );


    SET @p_msg_status            = p_msg_status;
    SET @p_mt_report_code_ib     = p_mt_report_code_ib;
    SET @p_mt_pr                 = p_mt_pr;

    PREPARE stmt FROM @sql;
    EXECUTE stmt USING @p_msg_status, @p_mt_report_code_ib, @p_mt_pr;

END
//


/**************************************************************************/
/* NAME : sp_mmt_tran_rslt_update
/* DESC : 메시지 전송 결과를 업데이트 한다.
/* PARAMETERS
/*   IN p_mt_report_code_ib     : 결과코드
/*   IN p_mt_report_code_ibtype : 결과코드 분류
/*   IN p_rs_id                 : 전송 RS아이디
/*   IN p_client_msg_key        : 전송키(mt_pr)
/*   IN p_msg_status            : 전송키의 하위 순번(mt_seq)
/*   IN p_carrier               : 전송 코드
/*   IN p_date_rslt             : 단말기 도착시각
/*   IN p_mt_res_cnt            : 중국 국제 문자 report count
/* REMARK
/*   N/A
/**************************************************************************/
DROP PROCEDURE IF EXISTS sp_mmt_tran_rslt_update //
CREATE PROCEDURE sp_mmt_tran_rslt_update
(
     IN p_mt_report_code_ib      CHAR(4)
   , IN p_mt_report_code_ibtype  CHAR(1)
   , IN p_rs_id                  VARCHAR(20)
   , IN p_client_msg_key         INT
   , IN p_recipient_order        INT
   , IN p_carrier                INT
   , IN p_date_rslt              DATETIME
   , IN p_mt_res_cnt             INT
)
BEGIN

    UPDATE ata_mmt_tran
    SET    msg_status            = '3'
         , date_rslt             = p_date_rslt
         , date_mt_report        = sysdate()
         , report_code           = p_mt_report_code_ib
         , rs_id                 = p_rs_id
    WHERE mt_pr = p_client_msg_key;

END
//

/**************************************************************************/
/* NAME : sp_mmt_tran_log_move
/* DESC : ata_mmt_tran테이블의 전송 완료된 메시지를 로그 테이블로 이동한다.
/* PARAMETERS
/*   IN p_ata_id : ATA 이중화시 사용되는 ATA ID (' ' 인 경우: 이중화 사용안함, ' ' 아닌 경우: 이중화 사용함)
/* REMARK
/*   N/A
/**************************************************************************/
DROP PROCEDURE IF EXISTS sp_mmt_tran_log_move //
CREATE PROCEDURE sp_mmt_tran_log_move
(
     IN  p_ata_id  CHAR(2)
)
BEGIN

    DECLARE v_done              INT DEFAULT 0; DECLARE v_date_client_req
    VARCHAR(8); DECLARE v_log_table         VARCHAR(6); DECLARE v_cnt
    INT;

    DECLARE v_cursor CURSOR FOR

      SELECT A.DATE_CLIENT_REQ
           , count(*) AS cnt
      FROM   ( SELECT DATE_FORMAT(date_client_req, '%Y%m%d') AS date_client_req
               FROM   ata_mmt_tran
               WHERE  ata_id = p_ata_id
               AND    msg_status = '3'
               LIMIT  1000
            ) A
      GROUP BY DATE_FORMAT(A.date_client_req, '%Y%m%d')
      LIMIT 5;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = 1;
    DECLARE CONTINUE HANDLER FOR SQLWARNING ROLLBACK;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION ROLLBACK;

    /*set transaction isolation level READ UNCOMMITTED;*/
    SET v_done=0;
    CALL sp_mmt_log_temp_create();
      OPEN v_cursor;

    cursor_loop:LOOP
    FETCH v_cursor INTO v_date_client_req, v_cnt;
    IF v_done = 1 THEN
        LEAVE cursor_loop;
    END IF;

    SET v_log_table = SUBSTRING(v_date_client_req,1,6);
    CALL sp_mmt_log_create(v_log_table);

    INSERT IGNORE INTO ata_mmt_log_temp
           SELECT mt_pr
                , mt_refkey
                , priority
                , date_client_req
                , subject
                , content
                , callback
                , msg_status
                , recipient_num
                , date_mt_sent
                , date_rslt
                , date_mt_report
                , report_code
                , rs_id
                , country_code
                , msg_type
                , crypto_yn
                , ata_id
                , reg_date
                , CURRENT_TIMESTAMP
                , sender_key
                , template_code
                , response_method
                , ad_flag
				, kko_btn_type
		        , kko_btn_info
				, img_url
                , img_link
                , etc_text_1
                , etc_text_2
                , etc_text_3
                , etc_num_1
                , etc_num_2
                , etc_num_3
                , etc_date_1
          FROM   ata_mmt_tran
          WHERE  ata_id = p_ata_id
          AND    msg_status = '3'
          AND    DATE_FORMAT(date_client_req, '%Y%m%d') = v_date_client_req
          AND    ss_ata_mmt_get_mt_pr() <> mt_pr
          LIMIT 2000;

    SET @sql_insert = CONCAT("
        INSERT IGNORE INTO ata_mmt_log_", v_log_table , "
               SELECT mt_pr
                    , mt_refkey
                    , priority
                    , date_client_req
                    , subject
                    , content
                    , callback
                    , msg_status
                    , recipient_num
                    , date_mt_sent
                    , date_rslt
                    , date_mt_report
                    , report_code
                    , rs_id
                    , country_code
                    , msg_type
                    , crypto_yn
                    , ata_id
                    , reg_date_tran
                    , CURRENT_TIMESTAMP
                    , sender_key
                    , template_code
                    , response_method
                    , ad_flag
					, kko_btn_type
		            , kko_btn_info
					, img_url
                    , img_link
                    , etc_text_1
                    , etc_text_2
                    , etc_text_3
                    , etc_num_1
                    , etc_num_2
                    , etc_num_3
                    , etc_date_1
               FROM   ata_mmt_log_temp ");

    START TRANSACTION;

    PREPARE stmt_insert FROM @sql_insert;
    EXECUTE stmt_insert;
    DEALLOCATE PREPARE stmt_insert;

    DELETE FROM ata_mmt_tran USING ata_mmt_tran
    INNER  JOIN ata_mmt_log_temp
    ON ata_mmt_tran.mt_pr = ata_mmt_log_temp.mt_pr;

    TRUNCATE TABLE ata_mmt_log_temp;

    COMMIT;

    END LOOP cursor_loop;

    CLOSE v_cursor;

    SET v_done=0;

END
//

/**************************************************************************/
/* NAME : sp_mmt_tran_log_move_past
/* DESC : ata_mmt_tran테이블의 유효기간이 지난 메시지를 로그 테이블로 이동한다.
/* PARAMETERS
/*   IN p_ata_id : ATA 이중화시 사용되는 ATA ID (' ' 인 경우: 이중화 사용안함, ' ' 아닌 경우: 이중화 사용함)
/* REMARK
/*   N/A
/**************************************************************************/
DROP PROCEDURE IF EXISTS sp_mmt_tran_log_move_past //
CREATE PROCEDURE sp_mmt_tran_log_move_past
(
     IN p_ata_id  CHAR(2)
)
BEGIN

    DECLARE v_done              INT DEFAULT 0;
    DECLARE v_date_client_req   VARCHAR(8);
    DECLARE v_log_table         VARCHAR(6);
    DECLARE v_cnt               INT;

    DECLARE v_cursor CURSOR FOR
        SELECT DATE_FORMAT(date_client_req, '%Y%m%d') AS date_client_req
             , count(*) AS cnt
        FROM   ata_mmt_tran
        WHERE  ata_id = p_ata_id
        AND    date_client_req < DATE_SUB(sysdate(),INTERVAL 3 DAY)
        AND    msg_status <> '3'
        GROUP BY DATE_FORMAT(date_client_req, '%Y%m%d')
        LIMIT 300;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = 1;
    DECLARE CONTINUE HANDLER FOR SQLWARNING ROLLBACK;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION ROLLBACK;

    /*set transaction isolation level READ UNCOMMITTED;*/

    SET v_done=0;
    CALL sp_mmt_log_temp_create();
    OPEN v_cursor;

    cursor_loop:LOOP
        FETCH v_cursor INTO v_date_client_req, v_cnt;
        IF v_done = 1 THEN
            LEAVE cursor_loop;
        END IF;

    SET v_log_table = SUBSTRING(v_date_client_req,1,6);
    CALL sp_mmt_log_create(v_log_table);

    INSERT IGNORE INTO ata_mmt_log_temp
    SELECT mt_pr
         , mt_refkey
         , priority
         , date_client_req
         , subject
         , content
         , callback
         , msg_status
         , recipient_num
         , date_mt_sent
         , date_rslt
         , date_mt_report
         , report_code
         , rs_id
         , country_code
         , msg_type
         , crypto_yn
         , ata_id
         , reg_date
         , CURRENT_TIMESTAMP
         , sender_key
         , template_code
         , response_method
         , ad_flag
		 , kko_btn_type
		 , kko_btn_info
		 , img_url
         , img_link
         , etc_text_1
         , etc_text_2
         , etc_text_3
         , etc_num_1
         , etc_num_2
         , etc_num_3
         , etc_date_1
    FROM   ata_mmt_tran
    WHERE  ata_id = p_ata_id
    AND    DATE_FORMAT(date_client_req, '%Y%m%d') = v_date_client_req
    AND    msg_status <> '3'
    AND    ss_ata_mmt_get_mt_pr() <> mt_pr
    LIMIT  50000;

    SET @sql_insert = CONCAT("
        INSERT IGNORE INTO ata_mmt_log_", v_log_table , "
               SELECT mt_pr
                    , mt_refkey
                    , priority
                    , date_client_req
                    , subject
                    , content
                    , callback
                    , msg_status
                    , recipient_num
                    , date_mt_sent
                    , date_rslt
                    , date_mt_report
                    , report_code
                    , rs_id
                    , country_code
                    , msg_type
                    , crypto_yn
                    , ata_id
                    , reg_date_tran
                    , CURRENT_TIMESTAMP
                    , sender_key
                    , template_code
                    , response_method
                    , ad_flag
					, kko_btn_type
		            , kko_btn_info
					, img_url
                    , img_link
                    , etc_text_1
                    , etc_text_2
                    , etc_text_3
                    , etc_num_1
                    , etc_num_2
                    , etc_num_3
                    , etc_date_1
               FROM   ata_mmt_log_temp ");

    START TRANSACTION;

    PREPARE stmt_insert FROM @sql_insert;
    EXECUTE stmt_insert;
    DEALLOCATE PREPARE stmt_insert;

    DELETE FROM ata_mmt_tran USING ata_mmt_tran
    INNER JOIN ata_mmt_log_temp
    ON ata_mmt_tran.mt_pr = ata_mmt_log_temp.mt_pr;

    TRUNCATE TABLE ata_mmt_log_temp;

    COMMIT;

    END LOOP cursor_loop;

    CLOSE v_cursor;

    SET v_done=0;

END
//

/****************************************************************************/
/* NAME : ss_ata_mmt_get_mt_pr                                               */
/* DESC : 로그테이블로 이동하는 데이터의 max mt_pr 값을 구한다.             */
/* PARAMETERS                                                               */
/*   N/A                                                                    */
/* RETURN                                                                   */
/*   v_mt_pr : max mt_pr 값                                                 */
/* REMARK                                                                   */
/*   N/A                                                                    */
/****************************************************************************/
DROP FUNCTION IF EXISTS ss_ata_mmt_get_mt_pr //
CREATE FUNCTION ss_ata_mmt_get_mt_pr
(

) RETURNS INT
BEGIN

    DECLARE v_mt_pr INT;

        SELECT MAX(mt_pr)
        INTO   v_mt_pr
        FROM  ata_mmt_tran;

        RETURN v_mt_pr;

END
//


/**************************************************************************/
/* NAME : sp_custom_failback_insert
/* DESC : 알림톡 실패 건 문자 메시지 재 전송
/* PARAMETERS
/*   IN p_client_msg_key        : 전송키(mt_pr)
/*   IN p_mt_report_code_ib     : 결과코드
/* REMARK
/*   N/A
/**************************************************************************/
DROP PROCEDURE IF EXISTS sp_custom_failback_insert //
CREATE PROCEDURE sp_custom_failback_insert
(
	   IN p_client_msg_key             INT
    ,IN p_mt_report_code_ib          CHAR(4)
)

BEGIN

	-- 결과코드 성공 이외의 건만 재 전송
    -- IF(p_mt_report_code_ib <>'1000') THEN
	--
    -- END IF;


END
//


DELIMITER ;
